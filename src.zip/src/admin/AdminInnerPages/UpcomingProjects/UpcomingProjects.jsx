import React from 'react'

function UpcomingProjects() {
  return (
    <div>UpcomingProjects</div>
  )
}

export default UpcomingProjects