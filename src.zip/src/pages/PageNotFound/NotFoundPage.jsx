import React from "react";
import "./NotFoundPage.css";

function NotFoundPage() {
  return (
    <>
      <div className="no-page-wrapper">
        <div className="no-inner-warpper">
          <p>404 | page not found</p>
        </div>
      </div>
    </>
  );
}

export default NotFoundPage;
